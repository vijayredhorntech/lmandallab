<!-- Topbar Start -->
















<!-- Topbar End -->


<!-- Brand Start -->
<div class="container-fluid bg-primary text-white pt-4 pb-5 d-none d-lg-flex">
    <div class="container pb-2">
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex">
                <i class="bi bi-telephone-inbound fs-2"></i>
                <div class="ms-3">
                    <h5 class="text-white mb-0">Call Now</h5>
                    <span>+012 345 6789</span>
                </div>
            </div>
            <a href="<?php echo e(route('index')); ?>" class="h1 text-white mb-0">IISER<span class="text-dark">lab</span></a>
            <div class="d-flex">
                <i class="bi bi-envelope fs-2"></i>
                <div class="ms-3">
                    <h5 class="text-white mb-0">Mail Now</h5>
                    <span>info@example.com</span>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Brand End -->


<!-- Navbar Start -->
<div class="container-fluid sticky-top">
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-lg-0 px-lg-3">
            <a href="<?php echo e(route('index')); ?>" class="navbar-brand d-lg-none">
                <h1 class="text-primary m-0">IISER<span class="text-dark">lab</span></h1>
            </a>
            <button type="button" class="navbar-toggler me-0" data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav">
                    <a href="<?php echo e(route('index')); ?>" class="nav-item nav-link <?php echo e(Route::currentRouteName()==='index'?'active':''); ?>">Home</a>
                    <a href="<?php echo e(route('research')); ?>" class="nav-item nav-link <?php echo e(Route::currentRouteName()==='research'?'active':''); ?>">Research</a>
                    <a href="<?php echo e(route('publications')); ?>" class="nav-item nav-link <?php echo e(Route::currentRouteName()==='publications'?'active':''); ?>">Publications</a>
                    <a href="<?php echo e(route('members')); ?>" class="nav-item nav-link <?php echo e(Route::currentRouteName()==='members'?'active':''); ?>">Members</a>
                    <a href="<?php echo e(route('photos')); ?>" class="nav-item nav-link <?php echo e(Route::currentRouteName()==='photos'?'active':''); ?>">Photos</a>
                    <a href="<?php echo e(route('contact')); ?>" class="nav-item nav-link <?php echo e(Route::currentRouteName()==='contact'?'active':''); ?>">Contact</a>






                </div>
                <div class="ms-auto d-none d-lg-flex">
                    <a class="btn btn-sm-square btn-primary ms-2" href="<?php echo e(route('index')); ?>"><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-sm-square btn-primary ms-2" href="<?php echo e(route('index')); ?>"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-sm-square btn-primary ms-2" href="<?php echo e(route('index')); ?>"><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-sm-square btn-primary ms-2" href="<?php echo e(route('index')); ?>"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
        </nav>
    </div>
</div>
<!-- Navbar End -->



<?php /**PATH D:\work\iiser_lab\resources\views/components/navbar.blade.php ENDPATH**/ ?>